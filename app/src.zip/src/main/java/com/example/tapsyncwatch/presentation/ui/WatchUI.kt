package com.example.tapsyncwatch.presentation.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tapsyncwatch.domain.clock.Clock
import com.example.tapsyncwatch.presentation.ui.components.GoblinFlash
import com.example.tapsyncwatch.presentation.ui.components.ResyncFlash

@Composable
fun WatchUI(
    clock: Clock,
    onTap: () -> Unit,
    onMultiply: () -> Unit,
    onDivide: () -> Unit,
    onResync: () -> Unit
) {
    val state by clock.stateFlow.collectAsState(
        initial = clock.state
    )

    var resyncFlashTrigger by remember { mutableStateOf(false) }
    var phaseOverride by remember { mutableStateOf<Double?>(null) }

    val bpm = state.bpm
    val phase = phaseOverride ?: state.phase

    // 👇 WICHTIG: eigene InteractionSource → kein System-Dismiss
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                onTap()
            },
        contentAlignment = Alignment.Center
    ) {

        ResyncFlash(
            trigger = resyncFlashTrigger,
            onConsumed = {
                resyncFlashTrigger = false
                phaseOverride = null
            }
        )

        GoblinFlash(phase = phase)

        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            Text(
                text = bpm.toInt().toString(),
                fontSize = 42.sp
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = "Phase: ${"%.2f".format(phase)}",
                fontSize = 14.sp
            )

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {

                Text(
                    text = "×2",
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onMultiply()
                    }
                )

                Text(
                    text = "÷2",
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onDivide()
                    }
                )
            }
        }
    }
}
