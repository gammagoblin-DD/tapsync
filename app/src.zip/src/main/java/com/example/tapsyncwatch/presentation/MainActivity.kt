package com.example.tapsyncwatch.presentation

import android.content.Context
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.example.tapsyncwatch.domain.clock.Clock
import com.example.tapsyncwatch.domain.clock.ClockEvent
import com.example.tapsyncwatch.input.osc.OscInputReceiver
import com.example.tapsyncwatch.presentation.ui.WatchUI
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var clock: Clock
    private lateinit var oscReceiver: OscInputReceiver
    private lateinit var wakeLock: PowerManager.WakeLock

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔒 Screen + CPU aktiv halten (Wear OS KRITISCH)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "TapSyncWatch::OscWakeLock"
        )
        wakeLock.acquire()

        clock = Clock()
        oscReceiver = OscInputReceiver(clock)

        // 🔁 Zentrale Clock-Tick-Loop
        lifecycleScope.launch {
            var lastTime = System.currentTimeMillis()
            while (true) {
                val now = System.currentTimeMillis()
                val delta = now - lastTime
                lastTime = now

                clock.handle(
                    ClockEvent.Tick(deltaMs = delta)
                )
                delay(16) // ~60 Hz
            }
        }

        setContent {
            WatchUI(
                clock = clock,
                onTap = {
                    clock.handle(
                        ClockEvent.Tap(
                            timestampMs = SystemClock.elapsedRealtime()
                        )
                    )
                },
                onMultiply = {
                    clock.handle(ClockEvent.Multiply)
                },
                onDivide = {
                    clock.handle(ClockEvent.Divide)
                },
                onResync = {
                    clock.handle(ClockEvent.Resync)
                }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        oscReceiver.start()   // 🎧 UDP Listener aktiv
    }

    override fun onStop() {
        super.onStop()
        oscReceiver.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (wakeLock.isHeld) {
            wakeLock.release()
        }
    }
}
