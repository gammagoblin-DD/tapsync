package com.example.tapsyncwatch.domain.clock

/**
 * ClockEvent beschreibt AUSSCHLIESSLICH semantische Ereignisse.
 *
 * Phase 2B:
 * - Zeit vergeht NUR über Tick(deltaMs)
 * - Tap liefert einen Zeitstempel (monoton)
 * - Keine Featureverluste
 */
sealed interface ClockEvent {

    // =====================================================
    // ZEIT
    // =====================================================
    data class Tick(
        val deltaMs: Long
    ) : ClockEvent

    // =====================================================
    // TAP (Zeitstempel kommt von außen)
    // =====================================================
    data class Tap(
        val timestampMs: Long
    ) : ClockEvent

    // =====================================================
    // EXTERNES BPM (Resolume / OSC)
    // =====================================================
    data class ExternalBpm(
        val bpm: Double
    ) : ClockEvent

    // =====================================================
    // TEMPO-OPERATIONEN
    // =====================================================
    object Multiply : ClockEvent
    object Divide : ClockEvent

    // =====================================================
    // RESYNC
    // =====================================================
    object Resync : ClockEvent

    // =====================================================
    // NUDGE (Phase 3, unverändert)
    // =====================================================
    sealed interface Nudge : ClockEvent {
        object LeftStart : Nudge
        object RightStart : Nudge
        object Stop : Nudge
    }
}
