package com.example.tapsyncwatch.domain.clock

/**
 * Read-only Zustand der Clock.
 *
 * Phase 2B:
 * - minimal
 * - vollständig beschreibend
 * - keine Tap-/Lock-/History-Felder
 */
data class ClockState(
    val bpm: Double,
    val phase: Double,      // 0.0 .. <1.0
    val isRunning: Boolean
)
